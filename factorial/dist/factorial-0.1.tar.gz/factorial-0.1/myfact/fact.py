def factorial(num):   # 返回给定数字的阶乘值
    if nun >= 0:
        if num == 0:
            return 1
        return  num * factorial(num -1)
    else:
        return -1
    
